# 🔐 DATA TAG Filtering System

## 🎯 مشکل
- چند اوپراتور با چند دستگاه B24 کار می‌کنن
- هر دستگاه یک DATA TAG منحصر به فرد داره
- اپ باید فقط از دستگاه‌های مربوط به پروژه فعلی داده بگیره

---

## ✅ راه‌حل

### چرا فرمت 2 (Legacy)?

**فرمت 1 (Pattern-Based):**
```
4D 80 6C C9 A4...
└──┘
این فقط یک پترن ثابته - همه دستگاه‌ها دارن! ❌
```

**فرمت 2 (Legacy):** ✅
```
01 4D 80 6C C9 A4...
   └──┘
   DATA TAG منحصر به فرد هر دستگاه!
```

---

## 📊 ساختار داده

### 1. Project Model
```dart
class Project {
  final String id;
  final String name;
  final String location;
  final List<int> deviceDataTags; // لیست DATA TAG های مجاز
  
  // مثال:
  // deviceDataTags: [0x4D80, 0x5A90, 0x6BC0]
}
```

### 2. Database Schema
```sql
CREATE TABLE projects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  location TEXT NOT NULL,
  createdAt INTEGER NOT NULL,
  deviceDataTags TEXT DEFAULT "" -- ذخیره به صورت CSV: "19840,23184,27584"
)
```

---

## 🔧 نحوه استفاده

### وقتی پروژه جدید ساخته میشه:

```dart
// اوپراتور DATA TAG های دستگاه‌هاش رو وارد می‌کنه
final project = Project(
  id: uuid(),
  name: "Site A",
  location: "Tehran",
  createdAt: DateTime.now().millisecondsSinceEpoch,
  deviceDataTags: [0x4D80, 0x5A90], // دستگاه A و B
);

await DatabaseHelper.instance.insertProject(project);
```

### وقتی مانیتورینگ شروع میشه:

```dart
// فیلتر رو تنظیم کن
B24BluetoothService.instance.setAllowedDataTags(project.deviceDataTags);

// شروع مانیتورینگ
await B24BluetoothService.instance.startBroadcastMonitoring();
```

### چی میشه؟

```
📡 دستگاه A (DATA TAG: 0x4D80) → ✅ قبول
📡 دستگاه B (DATA TAG: 0x5A90) → ✅ قبول  
📡 دستگاه C (DATA TAG: 0x6BC0) → 🚫 رد (متعلق به پروژه دیگه)
```

---

## 🔍 لاگ‌های Console

### دستگاه مجاز:
```
📦 Raw Manufacturer Data (0x04C3): 01 4D 80 6C C9...
   Data Tag: 19840 (0x4D80)
   ✅ DATA TAG 19840 matches project - ACCEPTING
   Decoded Data: 30 80 DC A9 3F 4D...
✅ B24 Data: Torque=123.45678 Nm
```

### دستگاه غیرمجاز:
```
📦 Raw Manufacturer Data (0x04C3): 01 6B C0 8A F1...
   Data Tag: 27584 (0x6BC0)
   🚫 DATA TAG 27584 (0x6BC0) not in allowed list - IGNORING
   📋 Allowed: 0x4D80, 0x5A90
```

---

## 🎨 UI Workflow

### 1. صفحه "Create Project"

```
┌─────────────────────────────────────┐
│  New Project                        │
├─────────────────────────────────────┤
│  Project Name: [____________]       │
│  Location:     [____________]       │
│                                     │
│  Devices:                           │
│  ┌───────────────────────────────┐ │
│  │ Device 1: 0x4D80             │ │
│  │ Device 2: 0x5A90             │ │
│  │ [+ Add Device]               │ │
│  └───────────────────────────────┘ │
│                                     │
│  [Create Project]                   │
└─────────────────────────────────────┘
```

### 2. چطوری DATA TAG رو بگیریم؟

**روش A: اسکن**
```dart
// اوپراتور دکمه "Scan Devices" رو می‌زنه
final devices = await B24BluetoothService.instance.scanDevices();

// لیست دستگاه‌ها با DATA TAG هاشون نمایش داده میشه
for (var device in devices) {
  print("${device.name}: DATA TAG = 0x${device.dataTag.toRadixString(16)}");
}
```

**روش B: دستی**
```
اوپراتور DATA TAG رو از روی برچسب دستگاه می‌خونه:
مثلاً: "B24-4D80" → DATA TAG = 0x4D80
```

---

## 📝 مثال کامل

### سناریو:
```
پروژه A: ساختمان برج میلاد
├─ دستگاه 1: B24-4D80 (DATA TAG: 0x4D80)
└─ دستگاه 2: B24-5A90 (DATA TAG: 0x5A90)

پروژه B: پارکینگ طبقاتی
└─ دستگاه 3: B24-6BC0 (DATA TAG: 0x6BC0)
```

### کد:
```dart
// ایجاد پروژه A
final projectA = Project(
  id: "proj-001",
  name: "Milad Tower",
  location: "Tehran",
  deviceDataTags: [0x4D80, 0x5A90],
);

// شروع کار روی پروژه A
B24BluetoothService.instance.setAllowedDataTags(projectA.deviceDataTags);
await B24BluetoothService.instance.startBroadcastMonitoring();

// نتیجه:
// ✅ دستگاه 1 و 2 → داده ذخیره میشه
// 🚫 دستگاه 3 → نادیده گرفته میشه
```

---

## 🔢 تبدیل DATA TAG

### از Hex به Decimal:
```dart
int dataTag = 0x4D80;  // Hex
print(dataTag);        // 19840 (Decimal)
```

### از Decimal به Hex:
```dart
int dataTag = 19840;
String hex = dataTag.toRadixString(16).toUpperCase(); // "4D80"
```

### ذخیره در Database:
```dart
// لیست به String
List<int> tags = [0x4D80, 0x5A90];
String csv = tags.join(','); // "19840,23184"

// String به لیست
String csv = "19840,23184";
List<int> tags = csv.split(',').map((e) => int.parse(e)).toList();
```

---

## ⚙️ API Methods

### تنظیم فیلتر:
```dart
// فقط این DATA TAG ها قبول میشن
B24BluetoothService.instance.setAllowedDataTags([0x4D80, 0x5A90]);
```

### پاک کردن فیلتر:
```dart
// همه دستگاه‌ها قبول میشن
B24BluetoothService.instance.clearDataTagFilter();
```

### چک کردن فیلتر فعلی:
```dart
if (_allowedDataTags.isEmpty) {
  print("No filter - accepting all devices");
} else {
  print("Filtering: ${_allowedDataTags.map((t) => '0x${t.toRadixString(16)}').join(', ')}");
}
```

---

## 🚀 مزایا

1. ✅ **امنیت:** فقط دستگاه‌های مجاز ذخیره میشن
2. ✅ **کارایی:** داده‌های غیرضروری فیلتر میشن
3. ✅ **صحت:** هر پروژه فقط داده‌های خودش رو داره
4. ✅ **چند اوپراتوری:** چند نفر می‌تونن همزمان کار کنن

---

## 🔐 امنیت

### مشکل احتمالی:
```
اگه اوپراتور اشتباهی DATA TAG اشتباه وارد کنه چی؟
```

### راه‌حل:
```dart
// وقتی monitoring شروع میشه، یک هشدار نشون بده:
if (noDataReceived for 30 seconds) {
  showDialog(
    title: "No Data Received",
    message: "Check if DATA TAG is correct: ${project.deviceDataTags}",
  );
}
```

---

## 📊 Dashboard

اوپراتور باید ببینه:
```
┌─────────────────────────────────┐
│  Active Devices:                │
├─────────────────────────────────┤
│  🟢 B24-4D80 | Torque: 123.45  │
│  🟢 B24-5A90 | Torque: 98.76   │
│  🔴 B24-6BC0 | Blocked         │
└─────────────────────────────────┘
```

---

## ✅ خلاصه

```
┌─────────────────────────────────────────┐
│  Create Project                          │
│  ├─ Enter device DATA TAGs              │
│  └─ Save to database                    │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Start Monitoring                        │
│  ├─ Set allowed DATA TAGs filter        │
│  ├─ Scan BLE advertising packets        │
│  └─ Accept only matching DATA TAGs      │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Receive Data                            │
│  ├─ Parse packet → Extract DATA TAG     │
│  ├─ Check if in allowed list            │
│  ├─ ✅ Match → Save to database         │
│  └─ 🚫 No match → Ignore                │
└─────────────────────────────────────────┘
```

---

**نتیجه:** اپ الان **فقط از دستگاه‌های مجاز** داده می‌گیره! 🎯
