# Changelog - B24 Torque Monitor

همه تغییرات مهم این پروژه در این فایل مستند می‌شود.

---

## [v1.1.0] - 2024-12-07

### 🐛 Fixed
- **مشکل Scan دستگاه‌ها حل شد**: وقتی دکمه Scan در Add Project زده می‌شد، هیچ دستگاهی پیدا نمی‌شد
  - اضافه شدن `DeviceDiscoveryInfo` class
  - اضافه شدن `discoveryStream` مخصوص Device Discovery
  - آپدیت شدن `_DeviceScanDialog` برای استفاده از stream جدید
  - نمایش اطلاعات بیشتر (نام دستگاه، DATA TAG، قدرت سیگنال)

### 🔧 Changed
- `bluetooth_service.dart`:
  - افزودن `DeviceDiscoveryInfo` class
  - افزودن `_discoveryController` و `discoveryStream`
  - افزودن `_discoveredDataTags` set برای جلوگیری از duplicate
  - emit کردن discovery event در `_parseLegacyFormat`
  
- `add_project_page.dart`:
  - تغییر `_DeviceScanDialog` برای استفاده از `discoveryStream`
  - نمایش RSSI (قدرت سیگنال) در لیست دستگاه‌ها
  - بهبود UI و پیغام‌های راهنما

### 📝 Documentation
- اضافه شدن `SCAN_FIX_DISCOVERY_STREAM.md` با توضیحات کامل

---

## [v1.0.0] - 2024-12-05

### ✅ Added
- **DATA TAG Filtering System**: فیلتر کردن دستگاه‌ها بر اساس DATA TAG های تعریف شده در پروژه
  - افزودن فیلد `deviceDataTags` به مدل Project
  - آپدیت Database به version 4
  - پشتیبانی از Legacy Format (Format ID 0x01)
  - UI برای اضافه کردن DATA TAG ها (Manual + Scan)
  - فیلتر خودکار در صفحه Monitoring

### 🔧 Changed
- `bluetooth_service.dart`:
  - حذف فرمت 2 (فقط Legacy Format پشتیبانی می‌شود)
  - اضافه شدن `setAllowedDataTags()` و `clearDataTagFilter()`
  - فیلتر کردن خودکار advertising packets

- `database_helper.dart`:
  - Migration به version 4
  - اضافه شدن ستون `device_data_tags` به جدول projects

### 📝 Documentation
- `DATA_TAG_FILTERING.md` - مستندات کامل سیستم فیلتر
- `IMPLEMENTATION_SUMMARY.md` - خلاصه پیاده‌سازی

---

## [v0.9.0] - 2024-12-03

### ✅ Added
- **Broadcast Mode Monitoring**: دریافت داده از advertising packets بدون نیاز به اتصال
  - استفاده از `continuousUpdates: true` در FlutterBluePlus
  - پشتیبانی از چند فرمت (Legacy و Format 2)
  - XOR Decryption با Default Seed و View PIN

### 🔧 Changed
- تغییر از Connection Mode به Broadcast Mode
- پشتیبانی از چند دستگاه همزمان
- بهبود performance و کاهش مصرف باتری

### 📝 Documentation
- `BROADCAST_MODE_FIXED.md` - توضیح Broadcast Mode
- `B24_BLUETOOTH_GUIDE.md` - راهنمای کامل Bluetooth

---

## [v0.8.0] - 2024-12-01

### ✅ Added
- **Auto Recording System**: ضبط خودکار داده‌ها وقتی گشتاور > 100 Nm
  - Session Management
  - Automatic pause/resume
  - Depth calculation

### 🔧 Changed
- بهبود Monitoring Page UI
- اضافه شدن Recording Status Indicator
- نمایش تعداد رکوردهای ذخیره شده

---

## [v0.7.0] - 2024-11-28

### ✅ Added
- **Project Management**: ایجاد، ویرایش، حذف پروژه‌ها
- **Excel Import**: import کردن اطلاعات شمع‌ها از فایل Excel
- **Pile Management**: مدیریت شمع‌های هر پروژه

### 📝 Database
- اضافه شدن جداول projects، piles، pile_sessions، measurements
- SQLite database با version 1

---

## [v0.5.0] - 2024-11-25

### ✅ Added
- **Login Page**: ورود با کد اپراتور ثابت (1234)
- **Bluetooth Service**: اتصال اولیه به دستگاه B24
- **Basic UI**: صفحات اصلی اپلیکیشن

### 🔧 Setup
- Flutter project initialization
- Dependencies: flutter_blue_plus, sqflite, excel, file_picker

---

## تعاریف

- **Added**: ویژگی‌های جدید
- **Changed**: تغییرات در ویژگی‌های موجود
- **Fixed**: رفع مشکلات و باگ‌ها
- **Removed**: حذف ویژگی‌ها
- **Security**: اصلاحات امنیتی
- **Documentation**: تغییرات در مستندات

---

## نکات نسخه‌گذاری

این پروژه از [Semantic Versioning](https://semver.org/) استفاده می‌کند:
- **MAJOR** (x.0.0): تغییرات ناسازگار با نسخه قبل
- **MINOR** (0.x.0): افزودن ویژگی جدید به صورت سازگار
- **PATCH** (0.0.x): رفع باگ به صورت سازگار
