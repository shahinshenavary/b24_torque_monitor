class Project {
  final String id;
  final String name;
  final String location;
  final int createdAt;
  final List<int> deviceDataTags; // List of DATA TAGs (hex values)

  Project({
    required this.id,
    required this.name,
    required this.location,
    required this.createdAt,
    this.deviceDataTags = const [], // Default empty
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'location': location,
      'createdAt': createdAt,
      'deviceDataTags': deviceDataTags.join(','), // Store as comma-separated string
    };
  }

  factory Project.fromMap(Map<String, dynamic> map) {
    // Parse comma-separated string back to List<int>
    final tagsString = map['deviceDataTags'] as String? ?? '';
    final tagsList = tagsString.isEmpty 
        ? <int>[]
        : tagsString.split(',').map((e) => int.parse(e)).toList();
    
    return Project(
      id: map['id'] as String,
      name: map['name'] as String,
      location: map['location'] as String,
      createdAt: map['createdAt'] as int,
      deviceDataTags: tagsList,
    );
  }

  Project copyWith({
    String? id,
    String? name,
    String? location,
    int? createdAt,
    List<int>? deviceDataTags,
  }) {
    return Project(
      id: id ?? this.id,
      name: name ?? this.name,
      location: location ?? this.location,
      createdAt: createdAt ?? this.createdAt,
      deviceDataTags: deviceDataTags ?? this.deviceDataTags,
    );
  }
}