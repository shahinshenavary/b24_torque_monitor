import 'dart:async';
import 'package:flutter/material.dart';
import '../services/bluetooth_service.dart';

class DebugBluetoothPage extends StatefulWidget {
  const DebugBluetoothPage({Key? key}) : super(key: key);

  @override
  State<DebugBluetoothPage> createState() => _DebugBluetoothPageState();
}

class _DebugBluetoothPageState extends State<DebugBluetoothPage> {
  final List<String> _logs = [];
  StreamSubscription<TorqueData>? _dataSubscription;
  StreamSubscription<DebugInfo>? _debugSubscription;
  bool _isMonitoring = false;
  TorqueData? _latestData;
  DebugInfo? _latestDebug;

  @override
  void initState() {
    super.initState();
    _setupStreams();
  }

  void _setupStreams() {
    _dataSubscription = B24BluetoothService.instance.dataStream.listen((data) {
      setState(() {
        _latestData = data;
        _addLog('📊 Data: Torque=${data.torque.toStringAsFixed(5)} Nm');
      });
    });

    _debugSubscription = B24BluetoothService.instance.debugStream.listen((info) {
      setState(() {
        _latestDebug = info;
        if (info.status.isNotEmpty) _addLog('📝 ${info.status}');
        if (info.error.isNotEmpty) _addLog('❌ ${info.error}');
      });
    });
  }

  void _addLog(String message) {
    setState(() {
      _logs.insert(0, '[${DateTime.now().toString().substring(11, 19)}] $message');
      if (_logs.length > 100) _logs.removeLast();
    });
  }

  Future<void> _startMonitoring() async {
    _addLog('🔍 Starting Broadcast Monitoring...');
    setState(() => _isMonitoring = true);
    
    try {
      await B24BluetoothService.instance.startBroadcastMonitoring();
      _addLog('✅ Monitoring started');
    } catch (e) {
      _addLog('❌ Error: $e');
      setState(() => _isMonitoring = false);
    }
  }

  Future<void> _stopMonitoring() async {
    _addLog('🛑 Stopping Broadcast Monitoring...');
    await B24BluetoothService.instance.stopBroadcastMonitoring();
    setState(() => _isMonitoring = false);
    _addLog('✅ Monitoring stopped');
  }

  void _clearLogs() {
    setState(() => _logs.clear());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bluetooth Debug'),
        actions: [
          IconButton(
            onPressed: _clearLogs,
            icon: const Icon(Icons.clear_all),
            tooltip: 'Clear Logs',
          ),
        ],
      ),
      body: Column(
        children: [
          // Control Panel
          Card(
            margin: const EdgeInsets.all(16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Broadcast Monitoring',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _isMonitoring ? null : _startMonitoring,
                          icon: const Icon(Icons.play_arrow),
                          label: const Text('Start Monitoring'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF10B981),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _isMonitoring ? _stopMonitoring : null,
                          icon: const Icon(Icons.stop),
                          label: const Text('Stop Monitoring'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFF87171),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Latest Data Display
          if (_latestData != null)
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Latest Data',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Torque: ${_latestData!.torque.toStringAsFixed(5)} Nm',
                      style: const TextStyle(fontSize: 24, color: Color(0xFF10B981)),
                    ),
                    const SizedBox(height: 8),
                    if (_latestDebug != null) ...[
                      Text('Raw Hex: ${_latestDebug!.rawHex}', 
                           style: const TextStyle(fontSize: 10, fontFamily: 'monospace')),
                      Text('Decoded Hex: ${_latestDebug!.decodedHex}', 
                           style: const TextStyle(fontSize: 10, fontFamily: 'monospace')),
                    ],
                  ],
                ),
              ),
            ),

          const SizedBox(height: 16),

          // Logs
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Text(
                  'Console Logs',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                Text(
                  '${_logs.length} entries',
                  style: const TextStyle(fontSize: 12, color: Color(0xFF9CA3AF)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),

          Expanded(
            child: Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF1F2937),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFF374151)),
              ),
              child: _logs.isEmpty
                  ? const Center(
                      child: Text(
                        'No logs yet. Start monitoring to see activity.',
                        style: TextStyle(color: Color(0xFF9CA3AF)),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _logs.length,
                      itemBuilder: (context, index) {
                        final log = _logs[index];
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Text(
                            log,
                            style: TextStyle(
                              fontSize: 11,
                              fontFamily: 'monospace',
                              color: log.contains('❌')
                                  ? const Color(0xFFF87171)
                                  : log.contains('✅')
                                      ? const Color(0xFF10B981)
                                      : log.contains('⚠️')
                                          ? const Color(0xFFFBBF24)
                                          : Colors.white,
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ),

          // Info Banner
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            color: const Color(0xFF1E3A8A),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '📡 Broadcast Mode - No Connection',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
                const SizedBox(height: 4),
                const Text(
                  '• App only listens to advertising packets',
                  style: TextStyle(fontSize: 10, color: Color(0xFF9CA3AF)),
                ),
                const Text(
                  '• Other apps can still connect to device',
                  style: TextStyle(fontSize: 10, color: Color(0xFF9CA3AF)),
                ),
                const Text(
                  '• Check console for detailed logs',
                  style: TextStyle(fontSize: 10, color: Color(0xFF9CA3AF)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _dataSubscription?.cancel();
    _debugSubscription?.cancel();
    B24BluetoothService.instance.stopBroadcastMonitoring();
    super.dispose();
  }
}
