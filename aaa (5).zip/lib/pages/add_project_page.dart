import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:excel/excel.dart';
import 'dart:io';
import 'dart:async';
import '../models/project.dart';
import '../models/pile.dart';
import '../database/database_helper.dart';
import '../services/bluetooth_service.dart';

class AddProjectPage extends StatefulWidget {
  final String operatorCode;

  const AddProjectPage({Key? key, required this.operatorCode}) : super(key: key);

  @override
  State<AddProjectPage> createState() => _AddProjectPageState();
}

class _AddProjectPageState extends State<AddProjectPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _locationController = TextEditingController();
  
  List<Pile> _piles = [];
  bool _isImporting = false;
  
  // Device DATA TAGs management
  List<int> _deviceDataTags = [];
  bool _isScanning = false;
  final TextEditingController _dataTagController = TextEditingController();

  Future<void> _importExcel() async {
    setState(() => _isImporting = true);

    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx', 'xls'],
      );

      if (result != null) {
        final file = File(result.files.single.path!);
        final bytes = await file.readAsBytes();
        final excel = Excel.decodeBytes(bytes);

        final tempProjectId = 'temp-${DateTime.now().millisecondsSinceEpoch}';
        List<Pile> importedPiles = [];

        for (var table in excel.tables.keys) {
          final sheet = excel.tables[table];
          if (sheet == null) continue;

          for (var i = 1; i < sheet.rows.length; i++) {
            final row = sheet.rows[i];
            if (row.length < 5) continue;

            final pileId = row[0]?.value?.toString() ?? '';
            final pileNumber = row[1]?.value?.toString() ?? '';
            final pileType = row[2]?.value?.toString() ?? '';
            final expectedTorque = double.tryParse(row[3]?.value?.toString() ?? '0') ?? 0;
            final expectedDepth = double.tryParse(row[4]?.value?.toString() ?? '0') ?? 0;

            if (pileId.isNotEmpty && pileNumber.isNotEmpty) {
              importedPiles.add(Pile(
                id: 'pile-${DateTime.now().millisecondsSinceEpoch}-$i',
                projectId: tempProjectId,
                pileId: pileId,
                pileNumber: pileNumber,
                pileType: pileType,
                expectedTorque: expectedTorque,
                expectedDepth: expectedDepth,
              ));
            }
          }
        }

        setState(() {
          _piles = importedPiles;
          _isImporting = false;
        });

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('${importedPiles.length} piles imported')),
          );
        }
      } else {
        setState(() => _isImporting = false);
      }
    } catch (e) {
      setState(() => _isImporting = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Import error: $e')),
        );
      }
    }
  }
  
  // Add DATA TAG manually
  void _addDataTagManually() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Device DATA TAG'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Enter the DATA TAG in hexadecimal format:'),
            const SizedBox(height: 8),
            const Text(
              'Example: 4D80, 5A90, 6BC0',
              style: TextStyle(fontSize: 12, color: Color(0xFF9CA3AF)),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _dataTagController,
              decoration: const InputDecoration(
                labelText: 'DATA TAG (Hex)',
                hintText: '4D80',
                prefixText: '0x',
              ),
              textCapitalization: TextCapitalization.characters,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final hexString = _dataTagController.text.trim().toUpperCase();
              if (hexString.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please enter a DATA TAG')),
                );
                return;
              }
              
              try {
                final dataTag = int.parse(hexString, radix: 16);
                
                if (_deviceDataTags.contains(dataTag)) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('DATA TAG already added')),
                  );
                  return;
                }
                
                setState(() {
                  _deviceDataTags.add(dataTag);
                });
                
                _dataTagController.clear();
                Navigator.pop(context);
                
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('DATA TAG 0x$hexString added')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Invalid hex format: $e')),
                );
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }
  
  // Scan for nearby B24 devices
  Future<void> _scanForDevices() async {
    setState(() => _isScanning = true);
    
    try {
      // Clear filter to see all devices
      B24BluetoothService.instance.clearDataTagFilter();
      
      // Start scanning
      await B24BluetoothService.instance.startBroadcastMonitoring();
      
      // Show dialog with discovered devices
      if (mounted) {
        await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => _DeviceScanDialog(
            onDeviceSelected: (dataTag) {
              if (!_deviceDataTags.contains(dataTag)) {
                setState(() {
                  _deviceDataTags.add(dataTag);
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Device DATA TAG 0x${dataTag.toRadixString(16).toUpperCase()} added')),
                );
              }
            },
          ),
        );
      }
      
      // Stop scanning
      await B24BluetoothService.instance.stopBroadcastMonitoring();
      
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Scan error: $e')),
        );
      }
    } finally {
      setState(() => _isScanning = false);
    }
  }
  
  // Remove DATA TAG
  void _removeDataTag(int dataTag) {
    setState(() {
      _deviceDataTags.remove(dataTag);
    });
  }

  Future<void> _saveProject() async {
    if (!_formKey.currentState!.validate()) return;
    if (_piles.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add at least one pile')),
      );
      return;
    }

    try {
      final project = Project(
        id: 'project-${DateTime.now().millisecondsSinceEpoch}',
        name: _nameController.text,
        location: _locationController.text,
        createdAt: DateTime.now().millisecondsSinceEpoch,
        deviceDataTags: _deviceDataTags, // ✅ Save DATA TAGs
      );

      await DatabaseHelper.instance.insertProject(project);

      final updatedPiles = _piles.map((pile) => pile.copyWith(projectId: project.id)).toList();
      await DatabaseHelper.instance.insertPiles(updatedPiles);

      if (mounted) {
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Save error: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Project'),
        actions: [
          TextButton.icon(
            onPressed: _saveProject,
            icon: const Icon(Icons.check),
            label: const Text('Save'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Project Information', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _nameController,
                        decoration: const InputDecoration(
                          labelText: 'Project Name',
                          prefixIcon: Icon(Icons.business),
                        ),
                        validator: (value) => value?.isEmpty ?? true ? 'Project name is required' : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _locationController,
                        decoration: const InputDecoration(
                          labelText: 'Location',
                          prefixIcon: Icon(Icons.location_on),
                        ),
                        validator: (value) => value?.isEmpty ?? true ? 'Location is required' : null,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Devices', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          Text('${_deviceDataTags.length} devices', style: const TextStyle(color: Color(0xFF9CA3AF))),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Add devices that will be used in this project',
                        style: TextStyle(fontSize: 12, color: Color(0xFF9CA3AF)),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _isScanning ? null : _scanForDevices,
                              icon: _isScanning
                                  ? const SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(strokeWidth: 2),
                                    )
                                  : const Icon(Icons.bluetooth_searching),
                              label: Text(_isScanning ? 'Scanning...' : 'Scan'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _addDataTagManually,
                              icon: const Icon(Icons.add),
                              label: const Text('Manual'),
                            ),
                          ),
                        ],
                      ),
                      if (_deviceDataTags.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        const Divider(),
                        const SizedBox(height: 8),
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _deviceDataTags.length,
                          itemBuilder: (context, index) {
                            final dataTag = _deviceDataTags[index];
                            final hexString = dataTag.toRadixString(16).padLeft(4, '0').toUpperCase();
                            return ListTile(
                              leading: const Icon(Icons.bluetooth, size: 20),
                              title: Text('B24-$hexString'),
                              subtitle: Text('DATA TAG: 0x$hexString'),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red, size: 20),
                                onPressed: () => _removeDataTag(dataTag),
                              ),
                              dense: true,
                            );
                          },
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Piles', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          Text('${_piles.length} piles', style: const TextStyle(color: Color(0xFF9CA3AF))),
                        ],
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: _isImporting ? null : _importExcel,
                          icon: _isImporting
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.upload_file),
                          label: Text(_isImporting ? 'Importing...' : 'Import from Excel'),
                        ),
                      ),
                      if (_piles.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        const Divider(),
                        const SizedBox(height: 8),
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _piles.length > 5 ? 5 : _piles.length,
                          itemBuilder: (context, index) {
                            final pile = _piles[index];
                            return ListTile(
                              leading: const Icon(Icons.push_pin, size: 20),
                              title: Text('${pile.pileId} - No. ${pile.pileNumber}'),
                              subtitle: Text('${pile.pileType} | ${pile.expectedTorque} Nm | ${pile.expectedDepth} m'),
                              dense: true,
                            );
                          },
                        ),
                        if (_piles.length > 5)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(
                              'and ${_piles.length - 5} more piles...',
                              style: const TextStyle(fontSize: 12, color: Color(0xFF9CA3AF)),
                            ),
                          ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _locationController.dispose();
    _dataTagController.dispose();
    super.dispose();
  }
}

class _DeviceScanDialog extends StatefulWidget {
  final Function(int) onDeviceSelected;

  const _DeviceScanDialog({Key? key, required this.onDeviceSelected}) : super(key: key);

  @override
  State<_DeviceScanDialog> createState() => _DeviceScanDialogState();
}

class _DeviceScanDialogState extends State<_DeviceScanDialog> {
  final Map<int, String> _discoveredDevices = {}; // DATA TAG -> Device Name
  late final StreamSubscription _debugSubscription;
  final RegExp _dataTagPattern = RegExp(r'Data Tag: (\d+) \(0x([0-9A-F]+)\)');

  @override
  void initState() {
    super.initState();
    _startListeningForDevices();
  }

  @override
  void dispose() {
    _debugSubscription.cancel();
    super.dispose();
  }

  void _startListeningForDevices() {
    // Listen to debug stream to extract DATA TAGs from advertising packets
    _debugSubscription = B24BluetoothService.instance.debugStream.listen((debugInfo) {
      // Parse DATA TAG from status messages
      final match = _dataTagPattern.firstMatch(debugInfo.status);
      if (match != null) {
        final dataTag = int.parse(match.group(1)!);
        final hexString = match.group(2)!;
        
        if (!_discoveredDevices.containsKey(dataTag)) {
          if (mounted) {
            setState(() {
              _discoveredDevices[dataTag] = 'B24-$hexString';
            });
          }
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Row(
        children: [
          const Text('Scanning for Devices'),
          const SizedBox(width: 8),
          SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
        ],
      ),
      content: SizedBox(
        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Tap on a device to add it to the project:'),
            const SizedBox(height: 8),
            Text(
              'Found ${_discoveredDevices.length} device(s)',
              style: const TextStyle(fontSize: 12, color: Color(0xFF9CA3AF)),
            ),
            const SizedBox(height: 16),
            if (_discoveredDevices.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: Column(
                    children: [
                      Icon(Icons.bluetooth_searching, size: 48, color: Color(0xFF9CA3AF)),
                      SizedBox(height: 8),
                      Text(
                        'Searching for B24 devices...',
                        style: TextStyle(color: Color(0xFF9CA3AF)),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Make sure devices are powered on',
                        style: TextStyle(fontSize: 12, color: Color(0xFF9CA3AF)),
                      ),
                    ],
                  ),
                ),
              )
            else
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _discoveredDevices.length,
                  itemBuilder: (context, index) {
                    final entry = _discoveredDevices.entries.elementAt(index);
                    final dataTag = entry.key;
                    final deviceName = entry.value;
                    final hexString = dataTag.toRadixString(16).padLeft(4, '0').toUpperCase();
                    
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.bluetooth, color: Colors.blue),
                        title: Text(deviceName),
                        subtitle: Text('DATA TAG: 0x$hexString (${dataTag})'),
                        trailing: const Icon(Icons.add_circle, color: Colors.green),
                        onTap: () {
                          widget.onDeviceSelected(dataTag);
                          Navigator.pop(context);
                        },
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
      actions: [
        TextButton.icon(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.close),
          label: const Text('Close'),
        ),
      ],
    );
  }
}