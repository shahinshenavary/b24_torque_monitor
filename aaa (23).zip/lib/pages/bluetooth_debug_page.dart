import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/bluetooth_service.dart';
import 'dart:async';

class BluetoothDebugPage extends StatefulWidget {
  const BluetoothDebugPage({Key? key}) : super(key: key);

  @override
  State<BluetoothDebugPage> createState() => _BluetoothDebugPageState();
}

class _BluetoothDebugPageState extends State<BluetoothDebugPage> {
  final List<DebugPacket> _packets = [];
  bool _isScanning = false;
  StreamSubscription? _debugSubscription;
  StreamSubscription? _discoverySubscription;
  int _packetsReceived = 0;
  final Set<int> _discoveredDataTags = {};

  @override
  void initState() {
    super.initState();
    _startListening();
  }

  void _startListening() {
    // Listen to debug stream
    _debugSubscription = B24BluetoothService.instance.debugStream.listen((debug) {
      if (debug.rawHex.isNotEmpty) {
        setState(() {
          _packetsReceived++;
          _packets.insert(0, DebugPacket(
            timestamp: DateTime.now(),
            rawHex: debug.rawHex,
            decodedHex: debug.decodedHex,
            status: debug.status,
            error: debug.error,
          ));
          
          // Keep only last 50 packets
          if (_packets.length > 50) {
            _packets.removeLast();
          }
        });
      }
    });

    // Listen to discovery stream
    _discoverySubscription = B24BluetoothService.instance.discoveryStream.listen((discovery) {
      setState(() {
        _discoveredDataTags.add(discovery.dataTag);
      });
    });
  }

  Future<void> _toggleScanning() async {
    if (_isScanning) {
      await B24BluetoothService.instance.stopBroadcastMonitoring();
      setState(() {
        _isScanning = false;
      });
    } else {
      try {
        setState(() {
          _packets.clear();
          _packetsReceived = 0;
          _discoveredDataTags.clear();
        });
        
        await B24BluetoothService.instance.startBroadcastMonitoring();
        
        setState(() {
          _isScanning = true;
        });
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  @override
  void dispose() {
    _debugSubscription?.cancel();
    _discoverySubscription?.cancel();
    if (_isScanning) {
      B24BluetoothService.instance.stopBroadcastMonitoring();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bluetooth Debug'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () {
              setState(() {
                _packets.clear();
                _packetsReceived = 0;
                _discoveredDataTags.clear();
              });
            },
            tooltip: 'Clear',
          ),
        ],
      ),
      body: Column(
        children: [
          // Control Panel
          Container(
            color: const Color(0xFFF3F4F6),
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _toggleScanning,
                        icon: Icon(_isScanning ? Icons.stop : Icons.play_arrow),
                        label: Text(_isScanning ? 'Stop Scanning' : 'Start Scanning'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _isScanning ? const Color(0xFFF87171) : const Color(0xFF10B981),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // Stats
                Row(
                  children: [
                    Expanded(
                      child: _StatCard(
                        label: 'Packets',
                        value: _packetsReceived.toString(),
                        icon: Icons.cell_tower,
                        color: const Color(0xFF3B82F6),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _StatCard(
                        label: 'Devices',
                        value: _discoveredDataTags.length.toString(),
                        icon: Icons.bluetooth,
                        color: const Color(0xFF10B981),
                      ),
                    ),
                  ],
                ),
                
                if (_discoveredDataTags.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFF10B981), width: 2),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.devices, size: 16, color: Color(0xFF10B981)),
                            SizedBox(width: 8),
                            Text(
                              'Discovered DATA TAGs:',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: _discoveredDataTags.map((tag) {
                            final hexString = tag.toRadixString(16).padLeft(4, '0').toUpperCase();
                            return Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: const Color(0xFF10B981),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    '0x$hexString',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    '($tag)',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 10,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  GestureDetector(
                                    onTap: () {
                                      Clipboard.setData(ClipboardData(text: hexString));
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: Text('Copied: $hexString'),
                                          duration: const Duration(seconds: 1),
                                        ),
                                      );
                                    },
                                    child: const Icon(Icons.copy, size: 14, color: Colors.white),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          
          // Packets List
          Expanded(
            child: _packets.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _isScanning ? Icons.sensors : Icons.bluetooth_disabled,
                          size: 64,
                          color: const Color(0xFF9CA3AF),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _isScanning ? 'Scanning for B24 devices...' : 'Press Start Scanning',
                          style: const TextStyle(color: Color(0xFF9CA3AF)),
                        ),
                        if (_isScanning) ...[
                          const SizedBox(height: 8),
                          const Text(
                            'Make sure device is active and broadcasting',
                            style: TextStyle(fontSize: 12, color: Color(0xFF9CA3AF)),
                          ),
                        ],
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _packets.length,
                    itemBuilder: (context, index) {
                      final packet = _packets[index];
                      return _PacketCard(packet: packet);
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 11, color: Color(0xFF9CA3AF)),
          ),
        ],
      ),
    );
  }
}

class _PacketCard extends StatelessWidget {
  final DebugPacket packet;

  const _PacketCard({required this.packet});

  @override
  Widget build(BuildContext context) {
    final hasError = packet.error.isNotEmpty;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Icon(
                  hasError ? Icons.error : Icons.check_circle,
                  color: hasError ? const Color(0xFFF87171) : const Color(0xFF10B981),
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _formatTime(packet.timestamp),
                    style: const TextStyle(fontSize: 12, color: Color(0xFF9CA3AF)),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.copy, size: 16),
                  onPressed: () {
                    Clipboard.setData(ClipboardData(
                      text: 'Raw: ${packet.rawHex}\nDecoded: ${packet.decodedHex}\nStatus: ${packet.status}',
                    ));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Copied to clipboard'),
                        duration: Duration(seconds: 1),
                      ),
                    );
                  },
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
            
            const SizedBox(height: 8),
            const Divider(),
            const SizedBox(height: 8),
            
            // Raw Data
            _DataSection(
              label: 'RAW (Encrypted)',
              data: packet.rawHex,
              color: const Color(0xFFF59E0B),
            ),
            
            const SizedBox(height: 8),
            
            // Decoded Data
            _DataSection(
              label: 'DECODED (After XOR)',
              data: packet.decodedHex,
              color: const Color(0xFF3B82F6),
            ),
            
            if (packet.status.isNotEmpty) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFD1FAE5),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info, size: 16, color: Color(0xFF065F46)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        packet.status,
                        style: const TextStyle(fontSize: 11, color: Color(0xFF065F46)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            
            if (hasError) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFEE2E2),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error, size: 16, color: Color(0xFF991B1B)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        packet.error,
                        style: const TextStyle(fontSize: 11, color: Color(0xFF991B1B)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}.${time.millisecond.toString().padLeft(3, '0')}';
  }
}

class _DataSection extends StatelessWidget {
  final String label;
  final String data;
  final Color color;

  const _DataSection({
    required this.label,
    required this.data,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    // Parse hex and show byte-by-byte breakdown
    final bytes = data.split(' ');
    final byteCount = bytes.length;
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '$byteCount bytes',
              style: const TextStyle(fontSize: 10, color: Color(0xFF9CA3AF)),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFFF9FAFB),
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: SelectableText(
            data,
            style: const TextStyle(
              fontFamily: 'monospace',
              fontSize: 11,
            ),
          ),
        ),
        
        // Byte-by-byte breakdown
        if (byteCount > 0) ...[
          const SizedBox(height: 4),
          Wrap(
            spacing: 4,
            runSpacing: 4,
            children: List.generate(byteCount, (index) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(3),
                  border: Border.all(color: color.withOpacity(0.3)),
                ),
                child: Text(
                  '[$index] ${bytes[index]}',
                  style: TextStyle(
                    fontSize: 9,
                    fontFamily: 'monospace',
                    color: color,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              );
            }),
          ),
        ],
      ],
    );
  }
}

class DebugPacket {
  final DateTime timestamp;
  final String rawHex;
  final String decodedHex;
  final String status;
  final String error;

  DebugPacket({
    required this.timestamp,
    required this.rawHex,
    required this.decodedHex,
    required this.status,
    required this.error,
  });
}
