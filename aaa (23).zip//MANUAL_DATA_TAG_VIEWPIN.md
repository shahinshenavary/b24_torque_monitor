# 📝 راهنمای DATA TAG و VIEW PIN دستی

## تغییرات نسخه v1.3.0

### ❌ حذف شده:
- دکمه **Scan** برای پیدا کردن دستگاه‌ها
- `_DeviceScanDialog` 
- قابلیت اسکن خودکار در Add Project

### ✅ اضافه شده:
- فیلد **VIEW PIN** در Add Project
- فیلد **DATA TAG** دستی با validation
- ذخیره VIEW PIN در دیتابیس
- استفاده خودکار از VIEW PIN پروژه در Monitoring

---

## 🎯 نحوه استفاده

### مرحله 1: ایجاد پروژه جدید

1. Login → Projects → **New Project**
2. پر کردن اطلاعات پروژه (نام، موقعیت)

### مرحله 2: تنظیم دستگاه

#### **A) VIEW PIN:**
- فیلد **VIEW PIN** رو پیدا کن
- پیش‌فرض: `0000`
- اگه VIEW PIN دستگاه متفاوته، تغییرش بده
- حداکثر 8 کاراکتر (0-9, A-Z, a-z)

#### **B) DATA TAG:**
- دکمه **"Add DATA TAG"** رو بزن
- Dialog باز میشه
- DATA TAG رو به فرمت HEX وارد کن (مثلا `4D80`)
- فقط 4 کاراکتر hex: `0-9` و `A-F`
- دکمه **Add** → DATA TAG اضافه میشه
- می‌تونی چندتا DATA TAG اضافه کنی (برای چند دستگاه)

### مرحله 3: Import شمع‌ها

- دکمه **"Import from Excel"**
- انتخاب فایل Excel

### مرحله 4: ذخیره

- دکمه **Save** در بالا
- پروژه ذخیره میشه با VIEW PIN و DATA TAG ها

---

## 📊 مثال

### پروژه با یک دستگاه:
```
Project Name: Building A - Foundation
Location: Tehran, District 2

VIEW PIN: 0000
DATA TAGs:
  - 0x4D80 (B24-4D80)
```

### پروژه با چند دستگاه:
```
Project Name: Building B - Piles
Location: Isfahan

VIEW PIN: 1234
DATA TAGs:
  - 0x4D80 (B24-4D80)
  - 0x5A90 (B24-5A90)
  - 0x6BC0 (B24-6BC0)
```

---

## 🔐 VIEW PIN چیست؟

VIEW PIN یک کد 4-8 کاراکتری است که برای **XOR Decryption** داده‌های B24 استفاده میشه.

### پیش‌فرض:
- VIEW PIN = `0000`
- اکثر دستگاه‌ها با این PIN کار می‌کنن

### اگه دستگاه PIN متفاوتی داره:
- از سازنده/فروشنده دستگاه VIEW PIN رو دریافت کن
- در هنگام ایجاد پروژه، PIN صحیح رو وارد کن
- اگه PIN اشتباه باشه، داده‌ها decode نمیشن!

---

## 🏷️ DATA TAG چیست؟

DATA TAG یک شناسه یکتا برای هر دستگاه B24 است که در **advertising packets** ارسال میشه.

### فرمت:
- 16-bit عدد به صورت Hexadecimal
- مثال: `4D80`, `5A90`, `6BC0`

### چطوری پیدا کنم؟

#### روش 1: از روی دستگاه
- روی دستگاه B24 یک برچسب یا display هست
- DATA TAG رو یادداشت کن
- به فرمت HEX (مثلا `4D80`)

#### روش 2: از Debug Scanner
1. برو Debug Scanner (دکمه 🐛)
2. دکمه **"Raw Scan"**
3. توی log ها دنبال این خط بگرد:
   ```
   🏷️ Legacy Format: DATA TAG = 19840 (0x4D80)
   ```
4. مقدار HEX رو (مثلا `4D80`) کپی کن

#### روش 3: از app دیگه (nRF Connect)
- دستگاه رو scan کن
- Manufacturer Data رو باز کن
- Byte 1-2 رو بخون (Little Endian)

---

## 🔧 تغییرات Database

### نسخه 5:
- اضافه شدن ستون `viewPin` به جدول `projects`

```sql
ALTER TABLE projects ADD COLUMN viewPin TEXT DEFAULT "0000"
```

### Migration خودکار:
- اگه از نسخه قبلی آپدیت کنی، migration خودکار اجرا میشه
- پروژه‌های قدیمی VIEW PIN پیش‌فرض `0000` می‌گیرن

---

## 📱 نحوه کار در Monitoring

وقتی Monitoring رو شروع می‌کنی:

1. **VIEW PIN پروژه** خوانده میشه
2. `B24BluetoothService.instance.setViewPin(project.viewPin)` فراخوانی میشه
3. **DATA TAG های پروژه** فیلتر میشن
4. فقط دستگاه‌هایی که DATA TAG شون در لیست پروژه هست، قبول میشن
5. Decryption با VIEW PIN صحیح انجام میشه

### Log ها:
```
🔐 VIEW PIN set to: 0000
🔐 Filtering devices for project 'Building A':
   Allowed DATA TAGs: 0x4D80, 0x5A90
```

---

## ⚠️ نکات مهم

### ✅ حتماً این کارها رو انجام بده:
1. **VIEW PIN صحیح:** اگه اشتباه باشه، داده decode نمیشه
2. **DATA TAG دقیق:** باید دقیقاً با دستگاه match کنه
3. **فرمت HEX:** فقط `0-9` و `A-F`
4. **حداقل یک DATA TAG:** بدون DATA TAG نمی‌تونی پروژه save کنی

### ❌ اشتباهات رایج:
1. **VIEW PIN اشتباه** → داده‌ها garbage می‌شن
2. **DATA TAG decimal** → باید HEX باشه (مثلا `4D80` نه `19840`)
3. **Case sensitive نبودن** → `4d80` و `4D80` یکسانه (auto uppercase میشه)

---

## 🧪 تست

### تست VIEW PIN:
1. پروژه با VIEW PIN ایجاد کن
2. برو Monitoring
3. چک کن log: `🔐 VIEW PIN set to: 0000`
4. اگه داده‌ها decode شدن → PIN صحیحه ✅
5. اگه داده‌ها garbage هستن → PIN اشتباهه ❌

### تست DATA TAG:
1. پروژه با DATA TAG ایجاد کن
2. برو Monitoring
3. چک کن log: `Allowed DATA TAGs: 0x4D80`
4. فقط دستگاه با همون DATA TAG باید accept بشه
5. دستگاه‌های دیگه: `🚫 DATA TAG ... not in allowed list - IGNORING`

---

## 📝 مثال کامل

```
🎯 Scenario: پروژه با 2 دستگاه B24

Project Info:
  Name: "Building Foundation"
  Location: "Tehran"
  
Device Config:
  VIEW PIN: "0000"
  DATA TAGs:
    - 0x4D80 (Device 1)
    - 0x5A90 (Device 2)
    
Excel Import:
  50 piles imported
  
Save → Done!

در Monitoring:
  ✅ Device B24-4D80 accepted
  ✅ Device B24-5A90 accepted
  ❌ Device B24-6BC0 rejected (not in list)
  
Decryption:
  VIEW PIN "0000" → Success ✅
  Torque data: 125.45 Nm
```

---

## 🔗 فایل‌های تغییر یافته

```
/aaa/lib/
├── models/
│   └── project.dart              ✅ اضافه شد viewPin field
├── database/
│   └── database_helper.dart      ✅ Migration به v5
└── pages/
    ├── add_project_page.dart     ✅ حذف Scan، اضافه Manual inputs
    └── monitoring_page.dart      ✅ استفاده از project.viewPin
```

---

## 📞 سوالات متداول

**Q: چطوری DATA TAG رو پیدا کنم؟**  
A: از Debug Scanner استفاده کن یا روی دستگاه برچسب داره

**Q: VIEW PIN پیش‌فرض چیه؟**  
A: `0000` - اکثر دستگاه‌ها این رو دارن

**Q: می‌تونم چند DATA TAG اضافه کنم؟**  
A: بله، برای هر دستگاه یکی

**Q: اگه VIEW PIN رو اشتباه بزنم چی میشه؟**  
A: داده‌ها decode نمیشن و عددهای اشتباه می‌بینی

**Q: می‌تونم بعداً VIEW PIN رو تغییر بدم؟**  
A: فعلاً نه، باید پروژه جدید بسازی. آپدیت بعدی اضافه میشه

---

**نسخه:** v1.3.0  
**تاریخ:** 2024-12-07
