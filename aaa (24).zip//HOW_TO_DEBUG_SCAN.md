# 🚀 راهنمای سریع: Debug کردن مشکل Scan

## مشکل شما:
**دستگاه B24 هنگام Scan پیدا نمی‌شه**

---

## ✅ راه‌حل سریع (5 دقیقه)

### **گام 1: باز کردن Debug Scanner**
1. اپلیکیشن رو باز کن
2. Login کن (کد: 1234)
3. صفحه Projects باز میشه
4. بزن روی آیکون 🐛 (گوشه بالا سمت راست)

### **گام 2: تست Raw Scan**
1. Toggle "Show All Devices" رو **ON** کن
2. دکمه **"Raw Scan"** رو بزن
3. منتظر بمون 10-20 ثانیه
4. به log ها نگاه کن

### **گام 3: تحلیل نتیجه**

#### ✅ حالت 1: دستگاه B24 پیدا شد
```
📱 Device: B24-4D80 (ID: ...) RSSI: -65 dBm
   📦 Mfg Data [0x04c3]: 01 80 4D ...
   🎯 B24 PATTERN FOUND at byte 1: 4D 80
   🏷️ Legacy Format: DATA TAG = 19840 (0x4D80)
```

**✅ عالی!** یعنی:
- Bluetooth کار می‌کنه
- Permission ها OK هستن
- دستگاه در حال broadcast هست

**➡️ بعدی:** برو به صفحه Add Project و دوباره Scan کن. باید کار کنه.

---

#### ⚠️ حالت 2: دستگاه پیدا میشه ولی داده نداره
```
📱 Device: B24-4D80 (ID: ...) RSSI: -65 dBm
   ⚠️ No manufacturer data
```

**علت:** دستگاه روشنه ولی broadcast نمی‌کنه

**راه‌حل:**
- دکمه روی دستگاه B24 رو بزن
- یک نیرو به سنسور وارد کن
- دستگاه رو restart کن
- دوباره Scan کن

---

#### ❌ حالت 3: دستگاه‌های دیگه رو می‌بینی ولی B24 نه
```
📡 Scan tick: 3 devices found
📱 Device: iPhone (ID: ...) RSSI: -45 dBm
📱 Device: Galaxy Watch (ID: ...) RSSI: -55 dBm
```

**علت:** B24 خیلی دوره یا خاموشه

**راه‌حل:**
- چک کن دستگاه B24 روشن باشه (LED روشن؟)
- نزدیک‌تر بیا (< 3 متر)
- باتری B24 رو چک کن
- دستگاه رو restart کن

---

#### ❌ حالت 4: هیچ دستگاهی پیدا نمیشه
```
📡 Scan tick: 0 devices found
📡 Scan tick: 0 devices found
```

**علت:** مشکل از Bluetooth یا Permission

**راه‌حل:**

**A) چک کردن Bluetooth:**
1. دکمه **"Check Permissions"** رو بزن
2. باید ببینی:
   ```
   ✅ Bluetooth is ON and ready
   ```

اگه دیدی:
```
❌ Bluetooth is OFF
```
→ برو Settings گوشی و Bluetooth رو روشن کن

**B) چک کردن Permission ها:**

**Android:**
1. Settings → Apps → B24 Torque Monitor
2. Permissions → باید اینا ON باشن:
   - ✅ Location (or Nearby Devices)
   - ✅ Bluetooth (if available)
3. همچنین GPS گوشی رو روشن کن (برای BLE scan لازمه)

**iOS:**
1. Settings → B24 Torque Monitor
2. Bluetooth → **Allow**
3. Location → **While Using**

**C) App رو Reinstall کن:**
اگه Manifest تغییر کرده، باید reinstall کنی:
```bash
flutter clean
flutter pub get
flutter run
```

---

## 🎯 خلاصه چک‌لیست

قبل از Scan، اینا رو چک کن:

- [ ] ✅ Bluetooth گوشی روشن هست؟
- [ ] ✅ GPS/Location روشن هست؟ (Android)
- [ ] ✅ Permissions داده شدن؟
- [ ] ✅ دستگاه B24 روشن هست؟
- [ ] ✅ دستگاه نزدیک هست؟ (< 5 متر)
- [ ] ✅ با Debug Scanner امتحان کردم؟

---

## 📞 هنوز حل نشد؟

اگه بعد از این مراحل هنوز کار نکرد:

1. **Screenshot از Debug Scanner** (با log ها) بگیر
2. **نوع گوشی و OS version** رو بنویس
3. **Output دکمه "Check Permissions"** رو copy کن
4. این اطلاعات رو بفرست

---

## 🔗 مستندات کامل

برای جزئیات بیشتر:
- `DEBUG_GUIDE_SCAN_TROUBLESHOOTING.md` - راهنمای کامل
- `SCAN_FIX_DISCOVERY_STREAM.md` - توضیح تغییرات
- `CHANGELOG.md` - تاریخچه نسخه‌ها

---

**موفق باشی! 🚀**
