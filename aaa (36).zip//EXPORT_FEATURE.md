# 📤 قابلیت Export پروژه به Excel

## ✨ ویژگی‌های جدید

قابلیت Export پروژه به فرمت Excel اضافه شد که به شما امکان می‌دهد گزارش کامل پروژه را ذخیره و با دیگران به اشتراک بگذارید.

---

## 🚀 نحوه استفاده

### 1️⃣ Export کردن پروژه

1. وارد صفحه **Projects** شوید
2. کنار هر پروژه، دکمه **سبز Export** (آیکون دانلود 📥) را خواهید دید
3. روی دکمه Export کلیک کنید
4. برنامه شروع به export می‌کند (دیالوگ Loading نمایش داده می‌شود)
5. پس از اتمام، مسیر ذخیره فایل نمایش داده می‌شود

### 2️⃣ پیدا کردن فایل Export شده

فایل‌های Excel در مسیر زیر ذخیره می‌شوند:

```
📁 /storage/emulated/0/Download/B24_Reports/
```

یا از طریق File Manager گوشی:

```
Files > Download > B24_Reports
```

### 3️⃣ فرمت نام فایل

```
ProjectName_YYYYMMDD_HHMM.xlsx
```

مثال:
```
Tehran_Metro_Line_7_20241207_1430.xlsx
```

---

## 📊 ساختار فایل Excel

فایل Excel شامل **3 Sheet** است:

### 📄 Sheet 1: Project Info

اطلاعات کلی پروژه:
- نام پروژه
- موقعیت
- تاریخ ایجاد
- تعداد شمع‌های Completed, In Progress, Pending
- تنظیمات دستگاه (VIEW PIN و DATA TAGs)

### 📋 Sheet 2: Piles Summary

خلاصه اطلاعات هر شمع:

| Pile ID | Pile Number | Type | Expected Torque | **Max Torque** | Expected Depth | **Final Depth** | Status | Measurements Count |
|---------|-------------|------|-----------------|----------------|----------------|-----------------|--------|-------------------|
| P-001 | 1 | H-Pile 300x300 | 450.0 | **478.5** | 12.5 | **12.8** | Completed | 245 |
| P-002 | 2 | H-Pile 300x300 | 450.0 | **N/A** | 12.5 | **N/A** | Pending | 0 |

**نکات:**
- ✅ **Max Torque**: حداکثر گشتاور ثبت شده برای هر شمع
- ✅ **Final Depth**: عمق نهایی شمع
- 🎨 Status با رنگ‌های مختلف نمایش داده می‌شود:
  - 🟢 سبز: Completed
  - 🟡 زرد: In Progress
  - ⚪ سفید: Pending

### 📈 Sheet 3: Detailed Measurements

تمام داده‌های ثبت شده (برای ساخت نمودار):

| Pile ID | Pile Number | Timestamp | **Torque (Nm)** | Depth (m) | Force (N) | Mass (kg) |
|---------|-------------|-----------|-----------------|-----------|-----------|-----------|
| P-001 | 1 | 2024/12/07 14:30:15 | 125.50 | 0.500 | 3200.0 | 850.0 |
| P-001 | 1 | 2024/12/07 14:30:16 | 234.75 | 1.250 | 6500.0 | 1200.0 |
| P-001 | 1 | 2024/12/07 14:30:17 | 378.20 | 2.800 | 9800.0 | 1650.0 |

---

## 📊 ساخت نمودار در Excel

### روش 1: نمودار Torque vs Time

1. فایل را در Excel باز کنید
2. به Sheet "Detailed Measurements" بروید
3. یک Pile ID را انتخاب کنید (مثلاً P-001)
4. داده‌های آن pile را فیلتر کنید
5. ستون‌های **Timestamp** و **Torque** را انتخاب کنید
6. برو به: **Insert → Chart → Line Chart**
7. نمودار گشتاور در طول زمان نمایش داده می‌شود

### روش 2: نمودار Torque vs Depth

1. ستون‌های **Depth** و **Torque** را انتخاب کنید
2. **Insert → Chart → Scatter Chart (XY)**
3. نمودار گشتاور بر حسب عمق نمایش داده می‌شود

### روش 3: مقایسه Max Torque شمع‌ها

1. به Sheet "Piles Summary" بروید
2. ستون‌های **Pile Number** و **Max Torque** را انتخاب کنید
3. **Insert → Chart → Column Chart**
4. مقایسه حداکثر گشتاور شمع‌ها نمایش داده می‌شود

---

## 🔒 امنیت و Backup

### ✅ مزایا:

1. **ذخیره دائمی**: فایل حتی با uninstall برنامه پاک نمی‌شود
2. **قابل انتقال**: فایل را می‌توانید به کامپیوتر منتقل کنید
3. **قابل اشتراک‌گذاری**: از طریق Email, Telegram, WhatsApp قابل ارسال است
4. **استاندارد**: فرمت Excel قابل باز شدن در تمام نرم‌افزارها

### 📤 اشتراک‌گذاری فایل:

1. فایل را در File Manager پیدا کنید
2. روی فایل Long Press کنید
3. گزینه **Share** را انتخاب کنید
4. روش ارسال را انتخاب کنید:
   - 📧 Email
   - 💬 Telegram
   - 💾 Google Drive
   - ☁️ Cloud Storage

---

## ⚠️ نکات مهم

### Storage Permission

برنامه به **Storage Permission** نیاز دارد:
- اولین بار که Export می‌کنید، اندروید از شما اجازه می‌خواهد
- حتماً **Allow** را بزنید
- بدون این مجوز، Export کار نمی‌کند

### مکان ذخیره‌سازی

- **اندروید**: `/storage/emulated/0/Download/B24_Reports/`
- فایل‌ها در پوشه **Download** قابل دسترسی هستند
- می‌توانید با USB به کامپیوتر متصل شوید و فایل‌ها را کپی کنید

### حجم فایل

تخمین حجم فایل Excel:
- پروژه کوچک (10 شمع، 1000 measurement): ~50 KB
- پروژه متوسط (50 شمع، 5000 measurement): ~250 KB  
- پروژه بزرگ (100 شمع، 10000 measurement): ~500 KB

---

## 🎯 Use Cases (موارد استفاده)

### 1. گزارش به مدیریت
Export کنید و از طریق Email به مدیر پروژه ارسال کنید

### 2. آرشیو و Backup
هر روز یا هر هفته پروژه را Export کنید و در Cloud ذخیره کنید

### 3. تحلیل داده‌ها
فایل را در Excel باز کنید و تحلیل‌های پیشرفته انجام دهید

### 4. مستندسازی
فایل Excel به عنوان مستندات رسمی پروژه نگهداری شود

### 5. اشتراک‌گذاری با تیم
فایل را با همکاران و مهندسین به اشتراک بگذارید

---

## 🐛 عیب‌یابی

### مشکل: Export انجام نمی‌شود

**راه‌حل:**
1. بررسی کنید Storage Permission داده‌اید
2. فضای کافی در گوشی داشته باشید (حداقل 10 MB)
3. اندروید را Restart کنید

### مشکل: فایل پیدا نمی‌شود

**راه‌حل:**
1. به مسیر `/storage/emulated/0/Download/B24_Reports/` بروید
2. از File Manager استفاده کنید نه Gallery
3. فایل را با نام پروژه + تاریخ جستجو کنید

### مشکل: Excel خطا می‌دهد

**راه‌حل:**
1. فایل را با Microsoft Excel یا Google Sheets باز کنید
2. مطمئن شوید فایل کامل دانلود شده
3. فایل Corrupted نباشد (دوباره Export کنید)

---

## 📝 تغییرات فنی

### فایل‌های تغییر یافته:

```
✅ pubspec.yaml                    → اضافه شدن permission_handler
✅ lib/services/excel_export_service.dart  → سرویس جدید Export
✅ lib/pages/projects_page.dart    → دکمه Export اضافه شد
✅ CORRECT_AndroidManifest.xml     → Storage permissions اضافه شد
```

### Permissions جدید:

```xml
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />
```

---

## 🎉 نتیجه

با این قابلیت:
- ✅ داده‌های پروژه امن هستند (حتی با uninstall)
- ✅ گزارش‌های حرفه‌ای قابل ارائه به مدیریت
- ✅ امکان تحلیل داده‌ها در Excel
- ✅ Backup خودکار و دستی
- ✅ اشتراک‌گذاری آسان

---

**توسعه دهنده**: B24 Torque Monitor Team  
**تاریخ**: 2024/12/07  
**نسخه**: 1.1.0
